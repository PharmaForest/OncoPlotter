filename P5C3D244 list;
%put NOTE: Unloading package OncoPlotter, version 0.5.3, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'ONCOPLOTTERMETA'
   ,'ONCOPLOTTERIML'
   ,'ONCOPLOTTERCASLUDF'
   %put NOTE- Element of type macros generated from the file "forest_plot.sas" will be deleted;
   %put NOTE- ;
   ,"FOREST_PLOT                                                     "
   %put NOTE- Element of type macros generated from the file "kaplan_meier_plot.sas" will be deleted;
   %put NOTE- ;
   ,"KAPLAN_MEIER_PLOT                                               "
   %put NOTE- Element of type macros generated from the file "sp_change.sas" will be deleted;
   %put NOTE- ;
   ,"SP_CHANGE                                                       "
   %put NOTE- Element of type macros generated from the file "sp_make_groupf_format.sas" will be deleted;
   %put NOTE- ;
   ,"SP_MAKE_GROUPF_FORMAT                                           "
   %put NOTE- Element of type macros generated from the file "sp_make_respf_format.sas" will be deleted;
   %put NOTE- ;
   ,"SP_MAKE_RESPF_FORMAT                                            "
   %put NOTE- Element of type macros generated from the file "sp_split_plot.sas" will be deleted;
   %put NOTE- ;
   ,"SP_SPLIT_PLOT                                                   "
   %put NOTE- Element of type macros generated from the file "spider_plot.sas" will be deleted;
   %put NOTE- ;
   ,"SPIDER_PLOT                                                     "
   %put NOTE- Element of type macros generated from the file "swimmer_plot.sas" will be deleted;
   %put NOTE- ;
   ,"SWIMMER_PLOT                                                    "
   %put NOTE- Element of type macros generated from the file "waterfall_plot.sas" will be deleted;
   %put NOTE- ;
   ,"WATERFALL_PLOT                                                  "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'ONCOPLOTTERFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.OncoPlotterfcmp.package;
quit;

proc fcmp outlib = work.OncoPlotterfcmp.packagemeta;
deletefunc OncoPlotterMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.oncoplotterfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
%put NOTE- Element of type data generated from the file "01_adsl_dummy.sas" will be deleted;
%put NOTE- ;
%sysfunc(ifc(%sysfunc(exist(01_adsl_dummy )),drop table 01_adsl_dummy ,));
%put NOTE- Element of type data generated from the file "02_adrs_dummy.sas" will be deleted;
%put NOTE- ;
%sysfunc(ifc(%sysfunc(exist(02_adrs_dummy )),drop table 02_adrs_dummy ,));
%put NOTE- Element of type data generated from the file "03_adtr_dummy.sas" will be deleted;
%put NOTE- ;
%sysfunc(ifc(%sysfunc(exist(03_adtr_dummy )),drop table 03_adtr_dummy ,));
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#oncoplotter(0.5.3)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#OncoPlotter(0.5.3)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package OncoPlotter, version 0.5.3, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
