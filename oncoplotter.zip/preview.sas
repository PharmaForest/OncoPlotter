filename P5C3D244 list;
 %put NOTE- ;
 %put NOTE: Preview of the OncoPlotter package, version 0.5.3, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-08-05T10:05:46; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include P5C3D244(packagemetadata.sas) / nosource2; 
data _null_;                                                 
  if strip(symget("helpKeyword")) = " " then                 
    do until (EOF);                                          
      infile P5C3D244(description.sas) end = EOF;  
      input;                                                 
      put _infile_;                                          
    end;                                                     
  else stop;                                                 
run;                                                         
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
04_data/04/data/01_adsl_dummy.sas/01_adsl_dummy/'01_adsl_dummy'
04_data/04/data/02_adrs_dummy.sas/02_adrs_dummy/'02_adrs_dummy'
04_data/04/data/03_adtr_dummy.sas/03_adtr_dummy/'03_adtr_dummy'
06_macros/06/macros/forest_plot.sas/forest_plot/'%forest_plot()'
06_macros/06/macros/kaplan_meier_plot.sas/kaplan_meier_plot/'%kaplan_meier_plot()'
06_macros/06/macros/sp_change.sas/sp_change/'%sp_change()'
06_macros/06/macros/sp_make_groupf_format.sas/sp_make_groupf_format/'%sp_make_groupf_format()'
06_macros/06/macros/sp_make_respf_format.sas/sp_make_respf_format/'%sp_make_respf_format()'
06_macros/06/macros/sp_split_plot.sas/sp_split_plot/'%sp_split_plot()'
06_macros/06/macros/spider_plot.sas/spider_plot/'%spider_plot()'
06_macros/06/macros/swimmer_plot.sas/swimmer_plot/'%swimmer_plot()'
06_macros/06/macros/waterfall_plot.sas/waterfall_plot/'%waterfall_plot()'
;;;;
run;
data _null_;                                                                        
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;      
if NOBS = 0 then do; 
put; put ' *> No preview. Try %previewPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                  
   set WORK._last_ end = EOFDS nobs = NOBS;                                         
   length memberX $ 1024;                                                           
   memberX = cats("_",folder,".",file);                                             
   call execute("data _null_;                                                    ");
   call execute('infile P5C3D244(' || strip(memberX) || ') end = EOF;  ');
   call execute("    do until(EOF);                                              ");
   call execute("      input;                                                    ");
   call execute("      put _infile_;                                             ");
   call execute("    end;                                                        ");
   call execute("  put "" "" / "" "";                                            ");
   call execute("  stop;                                                         ");
   call execute("run;                                                            ");
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Preview of the OncoPlotter package, version 0.5.3, license MIT;
%put NOTE- *** END ***;
/* preview.sas end */
