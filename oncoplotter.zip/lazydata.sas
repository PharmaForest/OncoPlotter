filename P5C3D244 list;
 %put NOTE- ;
 %put NOTE: Data for package OncoPlotter, version 0.5.3, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-08-05T10:05:46; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(OncoPlotter) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
if findw(lazyData, "01_adsl_dummy") then
do;
 put "NOTE- Dataset 01_adsl_dummy from the file ""01_adsl_dummy.sas"" will be loaded";
 call execute('%nrstr(%include P5C3D244(_04_data.01_adsl_dummy.sas) / nosource2;)');
end;
if findw(lazyData, "02_adrs_dummy") then
do;
 put "NOTE- Dataset 02_adrs_dummy from the file ""02_adrs_dummy.sas"" will be loaded";
 call execute('%nrstr(%include P5C3D244(_04_data.02_adrs_dummy.sas) / nosource2;)');
end;
if findw(lazyData, "03_adtr_dummy") then
do;
 put "NOTE- Dataset 03_adtr_dummy from the file ""03_adtr_dummy.sas"" will be loaded";
 call execute('%nrstr(%include P5C3D244(_04_data.03_adtr_dummy.sas) / nosource2;)');
end;
run;
%put NOTE- ;
%put NOTE: Data for package OncoPlotter, version 0.5.3, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
